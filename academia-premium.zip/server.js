const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/academia_premium';

// --- CONEXIÓN A MONGOOSE ---
mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('✅ Conectado a MongoDB perfectamente.');
    seedCourses();
  })
  .catch(err => console.error('❌ Error al conectar a MongoDB:', err));

// --- MODELOS DE DATOS ---
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  bio: { type: String, default: '¡Estudiante entusiasta en Academia Premium!' }
});

const CourseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  category: { type: String, required: true },
  price: { type: Number, required: true },
  discount: { type: Number, default: 0 },
  active: { type: Boolean, default: true },
  image: { type: String, default: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=600&auto=format&fit=crop' }
});

const User = mongoose.model('User', UserSchema);
const Course = mongoose.model('Course', CourseSchema);

// --- MIDDLEWARES ---
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(session({
  secret: 'secreto_academia_premium_2026',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 }
}));

// Obtener correos administradores
function getAdminEmails() {
  try {
    const data = fs.readFileSync(path.join(__dirname, 'admins.txt'), 'utf8');
    return data.split('\n').map(email => email.trim().toLowerCase()).filter(Boolean);
  } catch (err) {
    console.error("Error leyendo admins.txt, usando array vacío por defecto.", err);
    return [];
  }
}

app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.isAdmin = false;
  if (req.session.user) {
    const admins = getAdminEmails();
    if (admins.includes(req.session.user.email.toLowerCase())) {
      res.locals.isAdmin = true;
    }
  }
  next();
});

function requireAdmin(req, res, next) {
  if (!res.locals.isAdmin) {
    return res.status(403).send('Acceso denegado. No eres administrador.');
  }
  next();
}

// --- SEEDER DE 30 CURSOS PRECARGADOS ---
async function seedCourses() {
  const count = await Course.countDocuments();
  if (count === 0) {
    const categories = ['Desarrollo Web', 'Diseño UI/UX', 'Marketing Digital', 'Data Science', 'Negocios'];
    const sampleCourses = [];
    
    for (let i = 1; i <= 30; i++) {
      const cat = categories[i % categories.length];
      sampleCourses.push({
        title: `Curso Superior de ${cat} Vol. ${i}`,
        description: `Esta es la descripción profesional para el curso número ${i} de la especialidad de ${cat}. Aprende desde cero hasta nivel experto con proyectos reales y soporte 24/7.`,
        category: cat,
        price: Math.floor(Math.random() * (149 - 29 + 1)) + 29,
        discount: i % i === 0 && i % 3 === 0 ? 15 : 0,
        active: true,
        image: `https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=600&auto=format&fit=crop`
      });
    }
    await Course.insertMany(sampleCourses);
    console.log('🚀 30 cursos de prueba precargados con éxito.');
  }
}

// --- PLANTILLA MAESTRA DE INTERFAZ ---
function renderLayout(title, bodyHtml, activeTab = 'home', context) {
  const user = context.user;
  const isAdmin = context.isAdmin;
  
  return `
  <!DOCTYPE html>
  <html lang="es" class="h-full bg-slate-50">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>\${title} - Academia Premium</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  </head>
  <body class="h-full flex text-slate-800 font-sans antialiased">

    <!-- MENÚ LATERAL (IZQUIERDA) -->
    <aside class="w-64 bg-slate-900 text-white flex flex-col justify-between fixed inset-y-0 left-0 z-50 shadow-xl">
      <div>
        <div class="p-6 border-b border-slate-800 flex items-center space-x-3">
          <div class="bg-indigo-600 p-2 rounded-lg">
            <i class="fas fa-graduation-cap text-xl"></i>
          </div>
          <span class="font-bold text-lg tracking-wider bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">ACADEMIA</span>
        </div>

        <nav class="p-4 space-y-1">
          <a href="/" class="flex items-center space-x-3 px-4 py-3 rounded-lg transition \${activeTab === 'home' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}">
            <i class="fas fa-house-user w-5"></i> <span>Inicio</span>
          </a>
          <a href="/cursos" class="flex items-center space-x-3 px-4 py-3 rounded-lg transition \${activeTab === 'cursos' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}">
            <i class="fas fa-book-open w-5"></i> <span>Catálogo</span>
          </a>
          \${isAdmin ? `
            <a href="/admin" class="flex items-center space-x-3 px-4 py-3 rounded-lg transition \${activeTab === 'admin' ? 'bg-rose-600 text-white font-medium' : 'text-rose-400 hover:bg-slate-800 hover:text-white'}">
              <i class="fas fa-user-shield w-5"></i> <span class="font-bold">Admin Panel</span>
            </a>
          ` : ''}
        </nav>
      </div>

      <!-- Perfil / Ajustes abajo en el menú -->
      <div class="p-4 border-t border-slate-800 bg-slate-950/50">
        \${user ? `
          <div class="flex items-center justify-between">
            <a href="/perfil" class="flex items-center space-x-3 hover:opacity-80 transition group">
              <div class="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center font-bold text-white uppercase ring-2 ring-indigo-400/30">
                \${user.name.charAt(0)}
              </div>
              <div class="truncate w-32">
                <p class="text-sm font-semibold text-slate-200 truncate">\${user.name}</p>
                <p class="text-xs text-slate-500 truncate">Ver Ajustes</p>
              </div>
            </a>
            <a href="/logout" class="text-slate-500 hover:text-rose-400 p-2 rounded transition">
              <i class="fas fa-sign-out-alt"></i>
            </a>
          </div>
        ` : `
          <div class="space-y-2">
            <a href="/login" class="block text-center text-sm font-medium bg-slate-800 hover:bg-slate-700 text-white py-2 px-4 rounded-lg transition">Iniciar Sesión</a>
            <a href="/registro" class="block text-center text-sm font-medium bg-indigo-600 hover:bg-indigo-500 text-white py-2 px-4 rounded-lg transition">Registrarse</a>
          </div>
        `}
      </div>
    </aside>

    <!-- CONTENIDO PRINCIPAL -->
    <main class="flex-1 pl-64 min-h-screen flex flex-col">
      <header class="bg-white border-b border-slate-200 h-16 flex items-center justify-end px-8 sticky top-0 z-40">
        <div class="flex items-center space-x-4">
          <span class="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">Servidor en línea</span>
        </div>
      </header>
      
      <div class="p-8 flex-1">
        \${bodyHtml}
      </div>
    </main>

  </body>
  </html>
  `;
}

// --- CONTROLADORES DE RUTA ---

// HOME
app.get('/', async (req, res) => {
  const destacados = await Course.find({ active: true }).limit(3);
  let cards = destacados.map(c => {
    const precioFinal = c.price - (c.price * (c.discount / 100));
    return `
    <div class="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col justify-between">
      <img src="\${c.image}" class="h-44 w-full object-cover">
      <div class="p-5 flex-1 flex flex-col justify-between">
        <div>
          <span class="text-xs font-medium text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full uppercase">\${c.category}</span>
          <h3 class="font-bold text-lg text-slate-900 mt-2 line-clamp-1">\${c.title}</h3>
          <p class="text-slate-500 text-sm mt-1 line-clamp-2">\${c.description}</p>
        </div>
        <div class="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
          <div>
            \${c.discount > 0 ? `<span class="text-xs text-slate-400 line-through">$\${c.price}</span>` : ''}
            <span class="text-xl font-extrabold text-slate-900">$\${precioFinal.toFixed(2)}</span>
          </div>
          <a href="/cursos/\${c._id}" class="text-sm font-semibold text-indigo-600 hover:text-indigo-700">Ver Detalles &rarr;</a>
        </div>
      </div>
    </div>`;
  }).join('');

  let body = `
  <div class="max-w-5xl mx-auto space-y-12">
    <div class="bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 rounded-2xl p-12 text-white shadow-xl relative overflow-hidden">
      <h1 class="text-4xl md:text-5xl font-black tracking-tight leading-tight">Impulsa tu Futuro con <br><span class="bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent">Academia Premium</span></h1>
      <p class="text-slate-300 mt-4 max-w-xl text-lg">Acceso ilimitado a más de 30 cursos reales dictados por expertos del sector. Sin complicaciones.</p>
      <div class="mt-8">
        <a href="/cursos" class="bg-indigo-600 hover:bg-indigo-500 px-6 py-3 rounded-xl font-medium transition shadow-lg">Explorar Catálogo</a>
      </div>
    </div>
    <div>
      <h2 class="text-2xl font-bold text-slate-900 mb-6 flex items-center"><i class="fas fa-star text-amber-400 mr-2"></i> Cursos Destacados</h2>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">\${cards}</div>
    </div>
  </div>`;
  
  res.send(renderLayout('Inicio', body, 'home', res.locals));
});

// CATÁLOGO, BUSCADOR Y CATEGORÍAS
app.get('/cursos', async (req, res) => {
  const search = req.query.search || '';
  const category = req.query.category || '';
  
  let query = { active: true };
  if (search) query.title = { $regex: search, $options: 'i' };
  if (category) query.category = category;

  const courses = await Course.find(query);
  const categories = ['Desarrollo Web', 'Diseño UI/UX', 'Marketing Digital', 'Data Science', 'Negocios'];

  let courseGrid = courses.map(c => {
    const precioFinal = c.price - (c.price * (c.discount / 100));
    return `
    <div class="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col justify-between">
      <img src="\${c.image}" class="h-40 w-full object-cover">
      <div class="p-5 flex-1 flex flex-col justify-between">
        <div>
          <span class="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">\${c.category}</span>
          <h3 class="font-bold text-slate-900 mt-2 line-clamp-1">\${c.title}</h3>
          <p class="text-slate-500 text-xs mt-1 line-clamp-2">\${c.description}</p>
        </div>
        <div class="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
          <div>
            \${c.discount > 0 ? `<span class="text-xs text-slate-400 line-through">$\${c.price}</span> <span class="bg-rose-100 text-rose-700 font-bold text-[10px] px-1.5 py-0.5 rounded">-\${c.discount}%</span><br>` : ''}
            <span class="text-lg font-bold text-slate-900">$\${precioFinal.toFixed(2)}</span>
          </div>
          <a href="/cursos/\${c._id}" class="text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-indigo-600 hover:text-white px-3 py-2 rounded-lg transition">Ver más</a>
        </div>
      </div>
    </div>`;
  }).join('');

  let body = `
  <div class="max-w-6xl mx-auto space-y-6">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200">
      <form action="/cursos" method="GET" class="flex-1 flex gap-2">
        <input type="text" name="search" value="\${search}" placeholder="¿Qué quieres aprender hoy?..." class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
        <button type="submit" class="bg-indigo-600 text-white px-5 rounded-xl text-sm font-medium hover:bg-indigo-500 transition">Buscar</button>
      </form>
      <div class="flex gap-2 overflow-x-auto whitespace-nowrap">
        <a href="/cursos" class="px-4 py-2 rounded-xl text-xs font-medium border \${!category ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}">Todos</a>
        \${categories.map(cat => `
          <a href="/cursos?category=\${encodeURIComponent(cat)}" class="px-4 py-2 rounded-xl text-xs font-medium border \${category === cat ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}">\${cat}</a>
        `).join('')}
      </div>
    </div>
    
    \${courses.length === 0 ? `
      <div class="text-center py-12 bg-white rounded-xl border border-slate-200">
        <i class="fas fa-search text-slate-300 text-4xl mb-3"></i>
        <p class="text-slate-500 font-medium">No se encontraron cursos coincidentes.</p>
      </div>
    ` : `
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">\${courseGrid}</div>
    `}
  </div>`;

  res.send(renderLayout('Catálogo de Cursos', body, 'cursos', res.locals));
});

// DETALLE DEL CURSO
app.get('/cursos/:id', async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).send('Curso no encontrado');
    
    const precioFinal = course.price - (course.price * (course.discount / 100));
    let body = `
    <div class="max-w-4xl mx-auto bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
      <div class="relative h-64 md:h-96 bg-slate-900">
        <img src="\${course.image}" class="w-full h-full object-cover opacity-60">
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent p-8 flex flex-col justify-end">
          <span class="text-xs font-bold bg-indigo-600 text-white px-3 py-1 rounded-full uppercase w-max mb-3">\${course.category}</span>
          <h1 class="text-2xl md:text-4xl font-extrabold text-white">\${course.title}</h1>
        </div>
      </div>
      <div class="p-8 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div class="md:col-span-2 space-y-6">
          <div>
            <h2 class="text-lg font-bold text-slate-900 mb-2">Acerca de este curso</h2>
            <p class="text-slate-600 leading-relaxed text-sm md:text-base">\${course.description}</p>
          </div>
          <div class="bg-slate-50 p-4 rounded-xl border border-slate-100 grid grid-cols-2 gap-4 text-center">
            <div><p class="text-xs text-slate-400">Modalidad</p><p class="text-sm font-semibold text-slate-700"><i class="fas fa-laptop mr-1"></i> Online</p></div>
            <div><p class="text-xs text-slate-400">Acceso</p><p class="text-sm font-semibold text-slate-700"><i class="fas fa-infinity mr-1"></i> De por vida</p></div>
          </div>
        </div>
        <div class="bg-slate-50 p-6 rounded-xl border border-slate-200 h-max space-y-4">
          <div>
            <p class="text-xs text-slate-400 font-medium">Inversión única</p>
            <div class="flex items-baseline space-x-2 mt-1">
              <span class="text-3xl font-black text-slate-900">$\${precioFinal.toFixed(2)}</span>
              \${course.discount > 0 ? `<span class="text-sm text-slate-400 line-through">$\${course.price}</span>` : ''}
            </div>
          </div>
          <button onclick="alert('¡Inscripción simulada con éxito!')" class="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-500 transition shadow-lg shadow-indigo-600/10">Inscribirse Ahora</button>
        </div>
      </div>
    </div>`;
    res.send(renderLayout(course.title, body, 'cursos', res.locals));
  } catch(e) {
    res.status(500).send('Error interno');
  }
});

// LOGIN
app.get('/login', (req, res) => {
  let body = `
  <div class="max-w-md mx-auto mt-12 bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
    <h2 class="text-2xl font-bold text-slate-900 text-center">Iniciar Sesión</h2>
    <p class="text-xs text-slate-500 text-center mt-1">Accede a tu panel de Academia Premium</p>
    <form action="/login" method="POST" class="space-y-4 mt-6">
      <div>
        <label class="block text-xs font-semibold text-slate-600 uppercase">Email corporativo o personal</label>
        <input type="email" name="email" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-600 uppercase">Contraseña</label>
        <input type="password" name="password" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">
      </div>
      <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl font-semibold transition mt-2">Ingresar a la Plataforma</button>
    </form>
    <p class="text-xs text-slate-500 text-center mt-4">¿No tienes cuenta? <a href="/registro" class="text-indigo-600 font-semibold hover:underline">Regístrate aquí</a></p>
  </div>`;
  res.send(renderLayout('Login', body, 'home', res.locals));
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (user && await bcrypt.compare(password, user.password)) {
    req.session.user = { id: user._id, name: user.name, email: user.email, bio: user.bio };
    return res.redirect('/');
  }
  res.send("<script>alert('Credenciales incorrectas'); window.location='/login';</script>");
});

// REGISTRO
app.get('/registro', (req, res) => {
  let body = `
  <div class="max-w-md mx-auto mt-8 bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
    <h2 class="text-2xl font-bold text-slate-900 text-center">Crear Cuenta</h2>
    <p class="text-xs text-slate-500 text-center mt-1">Únete a la mejor comunidad de aprendizaje online</p>
    <form action="/registro" method="POST" class="space-y-4 mt-6">
      <div>
        <label class="block text-xs font-semibold text-slate-600 uppercase">Nombre Completo</label>
        <input type="text" name="name" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-600 uppercase">Correo Electrónico</label>
        <input type="email" name="email" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-600 uppercase">Contraseña</label>
        <input type="password" name="password" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">
      </div>
      <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl font-semibold transition mt-2">Comenzar Ahora</button>
    </form>
    <p class="text-xs text-slate-500 text-center mt-4">¿Ya tienes cuenta? <a href="/login" class="text-indigo-600 font-semibold hover:underline">Inicia Sesión</a></p>
  </div>`;
  res.send(renderLayout('Registro', body, 'home', res.locals));
});

app.post('/registro', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const existing = await User.findOne({ email });
    if (existing) return res.send("<script>alert('El correo ya está registrado'); window.location='/registro';</script>");
    
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hashedPassword });
    req.session.user = { id: user._id, name: user.name, email: user.email, bio: user.bio };
    res.redirect('/');
  } catch (e) {
    res.send("Error al crear usuario.");
  }
});

// LOGOUT
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// PERFIL & AJUSTES
app.get('/perfil', (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  const user = req.session.user;
  
  let body = `
  <div class="max-w-2xl mx-auto bg-white rounded-2xl border border-slate-200 shadow-sm p-8">
    <h2 class="text-2xl font-bold text-slate-900">Configuración del Perfil</h2>
    <p class="text-xs text-slate-500">Modifica tus datos de estudiante en Academia Premium</p>
    
    <form action="/perfil/update" method="POST" class="space-y-5 mt-6">
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-600 uppercase">Nombre</label>
          <input type="text" name="name" value="\${user.name}" required class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-600 uppercase">Correo (No modificable)</label>
          <input type="email" value="\${user.email}" disabled class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm mt-1 text-slate-400 cursor-not-allowed">
        </div>
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-600 uppercase">Biografía profesional</label>
        <textarea name="bio" rows="4" class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">\${user.bio || ''}</textarea>
      </div>
      <div class="pt-2 border-t border-slate-100 flex justify-end">
        <button type="submit" class="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2.5 rounded-xl font-medium text-sm transition">Guardar Cambios</button>
      </div>
    </form>
  </div>`;
  res.send(renderLayout('Mi Perfil', body, 'home', res.locals));
});

app.post('/perfil/update', async (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  const { name, bio } = req.body;
  await User.findByIdAndUpdate(req.session.user.id, { name, bio });
  req.session.user.name = name;
  req.session.user.bio = bio;
  res.send("<script>alert('Perfil actualizado con éxito'); window.location='/perfil';</script>");
});

// --- DASHBOARD ADMIN PANEL ---
app.get('/admin', requireAdmin, async (req, res) => {
  const courses = await Course.find();
  
  let rows = courses.map(c => `
  <tr class="border-b border-slate-100 text-sm hover:bg-slate-50/50 transition">
    <td class="p-4 font-semibold text-slate-900">\${c.title}</td>
    <td class="p-4 text-slate-500">\${c.category}</td>
    <td class="p-4 font-medium text-slate-800">$\${c.price}</td>
    <td class="p-4"><span class="bg-rose-100 text-rose-700 px-2 py-0.5 rounded text-xs font-bold">\${c.discount}%</span></td>
    <td class="p-4">
      <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold \${c.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'}">
        \${c.active ? 'Activo' : 'Inactivo'}
      </span>
    </td>
    <td class="p-4 flex space-x-2 justify-end">
      <button onclick="openEditModal('\${c._id}', '\${encodeURIComponent(c.title)}', '\${encodeURIComponent(c.description)}', '\${c.category}', \${c.price}, \${c.discount}, \${c.active})" class="text-indigo-600 hover:bg-indigo-50 px-2.5 py-1 rounded transition"><i class="fas fa-edit"></i></button>
      <a href="/admin/delete/\${c._id}" onclick="return confirm('¿Seguro de borrar este curso?')" class="text-rose-600 hover:bg-rose-50 px-2.5 py-1 rounded transition"><i class="fas fa-trash-alt"></i></a>
    </td>
  </tr>`).join('');

  let body = `
  <div class="max-w-6xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-2xl font-bold text-slate-900">Panel de Administración</h2>
        <p class="text-xs text-slate-500">Gestiona el catálogo completo de Academia Premium</p>
      </div>
      <button onclick="openCreateModal()" class="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2.5 rounded-xl text-sm font-semibold transition shadow-md"><i class="fas fa-plus mr-1"></i> Añadir Curso</button>
    </div>

    <!-- TABLA DE CURSOS -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <table class="w-full text-left border-collapse">
        <thead>
          <tr class="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase">
            <th class="p-4">Título del Curso</th>
            <th class="p-4">Categoría</th>
            <th class="p-4">Precio Original</th>
            <th class="p-4">Descuento</th>
            <th class="p-4">Estado</th>
            <th class="p-4 text-right">Acciones</th>
          </tr>
        </thead>
        <tbody>
          \${rows}
        </tbody>
      </table>
    </div>
  </div>

  <!-- MODAL FLOTANTE (CREAR / EDITAR) -->
  <div id="courseModal" class="hidden fixed inset-0 bg-slate-950/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
    <div class="bg-white rounded-2xl max-w-lg w-full p-6 border border-slate-200 shadow-2xl relative">
      <h3 id="modalTitle" class="text-xl font-bold text-slate-900">Añadir Nuevo Curso</h3>
      <form id="modalForm" action="/admin/create" method="POST" class="space-y-4 mt-4">
        <div>
          <label class="block text-xs font-semibold text-slate-600 uppercase">Título</label>
          <input type="text" name="title" id="formTitle" required class="w-full border border-slate-200 rounded-xl px-4 py-2 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-600 uppercase">Descripción</label>
          <textarea name="description" id="formDescription" required rows="3" class="w-full border border-slate-200 rounded-xl px-4 py-2 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none"></textarea>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-semibold text-slate-600 uppercase">Categoría</label>
            <select name="category" id="formCategory" class="w-full border border-slate-200 rounded-xl px-4 py-2 text-sm mt-1 bg-white outline-none">
              <option value="Desarrollo Web">Desarrollo Web</option>
              <option value="Diseño UI/UX">Diseño UI/UX</option>
              <option value="Marketing Digital">Marketing Digital</option>
              <option value="Data Science">Data Science</option>
              <option value="Negocios">Negocios</option>
            </select>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-600 uppercase">Estado</label>
            <select name="active" id="formActive" class="w-full border border-slate-200 rounded-xl px-4 py-2 text-sm mt-1 bg-white outline-none">
              <option value="true">Activo</option>
              <option value="false">Inactivo</option>
            </select>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-semibold text-slate-600 uppercase">Precio ($)</label>
            <input type="number" name="price" id="formPrice" required min="0" class="w-full border border-slate-200 rounded-xl px-4 py-2 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-600 uppercase">Descuento (%)</label>
            <input type="number" name="discount" id="formDiscount" required min="0" max="100" class="w-full border border-slate-200 rounded-xl px-4 py-2 text-sm mt-1 focus:ring-2 focus:ring-indigo-500 outline-none">
          </div>
        </div>
        <div class="pt-4 border-t border-slate-100 flex justify-end space-x-2">
          <button type="button" onclick="closeModal()" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-xl text-sm font-semibold transition">Cancelar</button>
          <button type="submit" class="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl text-sm font-semibold transition shadow-md">Guardar Curso</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    const modal = document.getElementById('courseModal');
    const modalForm = document.getElementById('modalForm');
    const modalTitle = document.getElementById('modalTitle');
    
    function openCreateModal() {
      modalTitle.innerText = 'Añadir Nuevo Curso';
      modalForm.action = '/admin/create';
      document.getElementById('formTitle').value = '';
      document.getElementById('formDescription').value = '';
      document.getElementById('formCategory').value = 'Desarrollo Web';
      document.getElementById('formActive').value = 'true';
      document.getElementById('formPrice').value = '49';
      document.getElementById('formDiscount').value = '0';
      modal.classList.remove('hidden');
    }

    function openEditModal(id, title, desc, cat, price, disc, active) {
      modalTitle.innerText = 'Editar Curso';
      modalForm.action = '/admin/edit/' + id;
      document.getElementById('formTitle').value = decodeURIComponent(title);
      document.getElementById('formDescription').value = decodeURIComponent(desc);
      document.getElementById('formCategory').value = cat;
      document.getElementById('formActive').value = active ? 'true' : 'false';
      document.getElementById('formPrice').value = price;
      document.getElementById('formDiscount').value = disc;
      modal.classList.remove('hidden');
    }

    function closeModal() {
      modal.classList.add('hidden');
    }
  </script>
  `;
  res.send(renderLayout('Panel Administrador', body, 'admin', res.locals));
});

// ACCIONES ADMIN
app.post('/admin/create', requireAdmin, async (req, res) => {
  const { title, description, category, price, discount, active } = req.body;
  await Course.create({ title, description, category, price, discount, active: active === 'true' });
  res.redirect('/admin');
});

app.post('/admin/edit/:id', requireAdmin, async (req, res) => {
  const { title, description, category, price, discount, active } = req.body;
  await Course.findByIdAndUpdate(req.params.id, { title, description, category, price, discount, active: active === 'true' });
  res.redirect('/admin');
});

app.get('/admin/delete/:id', requireAdmin, async (req, res) => {
  await Course.findByIdAndDelete(req.params.id);
  res.redirect('/admin');
});

// --- ARRANQUE DEL SERVIDOR ---
app.listen(PORT, () => {
  console.log(`🚀 Servidor Academia Premium corriendo en http://localhost:\${PORT}`);
});
